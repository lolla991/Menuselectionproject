import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CustomListener implements ActionListener {
    JButton btnClick;

    public void start(){
        JFrame jFrame = new JFrame("ActionListener Implementation");
        btnClick = new JButton("Open Dialog");
        btnClick.addActionListener(this);
        jFrame.add(btnClick);
        jFrame.setBounds(20,80,400,400);
        jFrame.setVisible(true);
        jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == btnClick){
            DialogMessage dlgMsg = new DialogMessage();
        }
    }

    static class DialogMessage extends JDialog implements ActionListener{
        DialogMessage(){
            JPanel jPanel = new JPanel();
            //jPanel.add(new JLabel("Dialog box"));
            jPanel.add(new JLabel("Btn Send Works"));
            this.add(jPanel);
            JPanel btnPnl  = new JPanel();
            JButton btnOK = new JButton("OK");
            btnOK.addActionListener(this);
            btnPnl.add(btnOK);
            this.add(btnPnl, BorderLayout.SOUTH);
            setDefaultCloseOperation(DISPOSE_ON_CLOSE);
            pack();
            setVisible(true);
        }
        @Override
        public void actionPerformed(ActionEvent e) {
            setVisible(false);
            dispose();
        }
    }
}
