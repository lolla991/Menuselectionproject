import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Menu extends JFrame implements ActionListener {
    //menu| we need a menubar,menu items

    static JMenuBar menuBar;
    static JMenu menu1,menu2;
    static JMenuItem item1, item2, item3, sItem1, sItem2, sItem3,sItem4;
    static JFrame menuFrame;
    static JLabel labelMessage;


    @Override
    public void actionPerformed(ActionEvent e) {
        String s = e.getActionCommand();

        //set the text of the selected menuItem
        labelMessage.setText(s + "Selected");
    }
}
