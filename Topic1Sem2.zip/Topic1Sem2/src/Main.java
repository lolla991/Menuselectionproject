import javax.swing.*;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        //TIP Press <shortcut actionId="ShowIntentionActions"/> with your caret at the highlighted text
        // to see how IntelliJ IDEA suggests fixing it.

        /* Swing and AWT are Java GUI frameworks
        * Swing is built on top of AWT
        * To create UI components on our Java app
        * we use JFrame
        * JFrame -> container that inherits from AWT.JFrame
        * we use it for top-level window in Java
        * */

       //Form form1 = new Form();

        //August fifth
//        CustomListener customListener = new CustomListener();
//        customListener.start();

        //August 12th
        Menu menu = new Menu();
        Menu.menuFrame = new JFrame("Menu example");
        Menu.labelMessage = new JLabel("Nothing is selected");
        //menuBar
        Menu.menuBar = new JMenuBar();
        //menu + Submenu
        Menu.menu1 = new JMenu("Menu");
        Menu.menu2 = new JMenu("Submenu");
        //menuItems
        Menu.item1 = new JMenuItem("File");
        Menu.item2 = new JMenuItem("Window");
        Menu.item3 = new JMenuItem("Edit");
        Menu.sItem1 = new JMenuItem("Version Control");
        Menu.sItem2 = new JMenuItem("Help");
        Menu.sItem3 = new JMenuItem("Update");
        Menu.sItem4 = new JMenuItem("Feedback");

        Menu.item1.addActionListener(menu);
        Menu.item2.addActionListener(menu);
        Menu.item3.addActionListener(menu);
        Menu.sItem1.addActionListener(menu);
        Menu.sItem2.addActionListener(menu);
        Menu.sItem3.addActionListener(menu);
        Menu.sItem4.addActionListener(menu);

        //add menuitems to actual menu
        Menu.menu1.add(Menu.item1);
        Menu.menu1.add(Menu.item2);
        Menu.menu1.add(Menu.item3);
        Menu.menu2.add(Menu.sItem1);
        Menu.menu2.add(Menu.sItem2);
        Menu.menu2.add(Menu.sItem3);
        Menu.menu2.add(Menu.sItem4);

        //submenu to menu
        Menu.menu1.add(Menu.menu2);

        Menu.menuBar.add(Menu.menu1);

        Menu.menuFrame.setJMenuBar(Menu.menuBar);

        Menu.menuFrame.add(Menu.labelMessage);

        Menu.menuFrame.setSize(400,400);
        Menu.menuFrame.setVisible(true);
    }
}