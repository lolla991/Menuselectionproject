//We'll use AWT for this one
public class Table {

    public Table(){
//        Frame tableFrame = new Frame("Table Layout");
//        tableFrame.setBounds(200,200,300,300);
//
//        //table Layout
//        double border = 10;
//        double size[][] =
//                {{border,0.10,20,TableLayout.FILL},//columns
//                        {}}; //rows
    }


}
