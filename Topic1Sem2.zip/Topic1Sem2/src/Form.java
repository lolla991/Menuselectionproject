import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Form {

    Form(){
        JFrame frame1 = new JFrame("User Details");

        JLabel firstName = new JLabel("First Name");
        firstName.setBounds(20,50,80,20);

        JTextField firstNameTxt = new JTextField();
        firstNameTxt.setBounds(20,80,200,20);

        JButton btnSend = new JButton("Send");
        btnSend.setBounds(20,100,80,20);

        frame1.add(firstName);
        frame1.add(firstNameTxt);
        frame1.add(btnSend);

        //Aug 5 - 2024 | ActionListener
        btnSend.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CustomListener.DialogMessage dlgMsg = new CustomListener.DialogMessage();
            }
        });

        frame1.setLayout(null);
        frame1.setSize(400,400);
        frame1.setVisible(true);

    }
}
